class WelcomeController < ApplicationController
   def index
      @background_pic = "sunsetpic"
   end
end
