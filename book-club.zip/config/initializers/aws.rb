S3 = Aws::S3::Resource.new
